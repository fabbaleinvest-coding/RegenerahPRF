const express = require('express');
const path = require('path');
const fs = require('fs/promises');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const LEADS_FILE = path.join(DATA_DIR, 'leads.json');

app.use(express.json({ limit: '1mb' }));
app.use(express.static(PUBLIC_DIR));

async function initStorage() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    await fs.access(LEADS_FILE);
  } catch {
    await fs.writeFile(LEADS_FILE, '[]', 'utf8');
  }
}

app.get('/', (_req, res) => {
  res.redirect('/regenerah-prf.html');
});

app.post('/api/contact', async (req, res) => {
  try {
    const { name, clinic, email, phone, role, message, consent, locale } = req.body || {};
    if (!name || !email || !message) {
      return res.status(400).json({ ok: false, error: 'Campi obbligatori mancanti.' });
    }
    if (!consent) {
      return res.status(400).json({ ok: false, error: 'Consenso privacy obbligatorio.' });
    }

    const leads = JSON.parse(await fs.readFile(LEADS_FILE, 'utf8'));
    leads.push({
      id: `lead_${Date.now()}`,
      createdAt: new Date().toISOString(),
      locale: locale || 'it',
      name: String(name).trim(),
      clinic: String(clinic || '').trim(),
      email: String(email).trim(),
      phone: String(phone || '').trim(),
      role: String(role || '').trim(),
      message: String(message).trim(),
      consent: Boolean(consent),
      source: 'REGENERAH PRF website'
    });
    await fs.writeFile(LEADS_FILE, JSON.stringify(leads, null, 2), 'utf8');
    res.json({ ok: true, message: locale === 'en' ? 'Request sent successfully.' : 'Richiesta inviata correttamente.' });
  } catch (error) {
    res.status(500).json({ ok: false, error: 'Errore interno del server.' });
  }
});

initStorage().then(() => {
  app.listen(PORT, () => console.log(`REGENERAH PRF running on http://localhost:${PORT}`));
});
