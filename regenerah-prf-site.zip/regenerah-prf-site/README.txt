REGENERAH PRF - Istruzioni rapide

1) Apri il terminale nella cartella del progetto.
2) Esegui: npm install
3) Esegui: npm start
4) Apri il browser su: http://localhost:3000

Struttura:
- public/regenerah-prf.html  -> frontend React + Tailwind + Framer Motion
- public/IMG_3325.jpeg       -> logo
- server.js                  -> backend Express per raccolta lead
- data/leads.json            -> salvataggio richieste dal form

Per cambiare la porta:
- Windows PowerShell: $env:PORT=3001; npm start
- macOS/Linux: PORT=3001 npm start
